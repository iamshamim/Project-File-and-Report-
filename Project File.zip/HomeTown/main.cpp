#include<windows.h>
#include <GL/glut.h>
#include <GL/gl.h>

float angle = 0.0, x=-4;

void home()
{

glPushMatrix(); //main building
   glColor3f(0.91, 1.76,1.65);
   glTranslated(0,0.4,0);
   glScaled(2,0.8,1);
   glutSolidCube(1);
   glColor3f(0.91, 0.76,0.65);
   glutWireCube(1);
   glPopMatrix();

   glPushMatrix(); //door
   glColor3f(0,0,0);
   glTranslated(0,0.2,0);
   glScaled(0.3,0.4,1);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();

   glPushMatrix(); //Window right
   glColor3f(0,2,1);
   glTranslated(0.7,0.3,0);
   glScaled(0.2,0.3,1);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();


 glPushMatrix(); //Window Left
   glColor3f(0,2,1);
   glTranslated(-0.7,0.3,-1);
   glScaled(0.2,0.3,1);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();



   glPushMatrix(); //main building roof
   glColor3f(0,0,0);
   glTranslated(0,0.8,0);
   glScaled(2,0.02,1);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();

   glPushMatrix(); //room on floor
   glColor3f(0.91, 0.76,0.65);
   glTranslated(0,1.1,0);
   glScaled(1.4,0.6,1);
   glutSolidCube(1);
   glColor3f(0.65, 0.49,0.24);
   glutWireCube(1);
   glPopMatrix();

   glPushMatrix(); //top room roof
   glColor3f(0,0,0);
   glTranslated(0,1.4,0);
   glScaled(1.5,0.03,1);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();

   glPushMatrix(); //top room window
   glColor3f(0,0,0);
   glTranslated(0,1.1,0);
   glScaled(0.4,0.3,1);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();


   glPushMatrix(); //sub building
   glColor3f(0.91, 1.76,1.65);
   glTranslated(-2.6,0.80,3.0);
   glScaled(.5,1.6,2);
   glutSolidCube(1);
   glColor3f(0.91, 0.76,0.65);
   glutWireCube(1);
   glPopMatrix();

 glPushMatrix(); // sub building door
   glColor3f(0,0,0);
   glTranslated(-2.6,0.15,1.9);
   glScaled(0.2,0.3,1);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();

      glPushMatrix(); // sub building Top door
   glColor3f(0,0,0);
   glTranslated(-2.6,.54,1.9);
   glScaled(0.2,0.3,1);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();

    glPushMatrix(); // sub building 3 door
   glColor3f(0,0,0);
   glTranslated(-2.6,.95,1.9);
   glScaled(0.2,0.3,1);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();

  glPushMatrix(); // sub building 4 door
   glColor3f(0,0,0);
   glTranslated(-2.6,1.35,1.9);
   glScaled(0.2,0.3,1);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();


   glPushMatrix(); //sub building 1st room roof
   glColor3f(0,0,0);
   glTranslated(-2.6,0.4,1.9);
   glScaled(1,0.02,1);
   glutSolidCube(.5);
   glColor3f(0,0,0);
   glutWireCube(0);
   glPopMatrix();


    glPushMatrix(); // sub building 2nd room roof
   glColor3f(0,0,0);
   glTranslated(-2.6,.8,1.9);
   glScaled(1,0.02,1);
   glutSolidCube(.5);
   glColor3f(0,0,0);
   glutWireCube(0);
   glPopMatrix();


    glPushMatrix(); // sub building 3rd room roof
   glColor3f(0,0,0);
   glTranslated(-2.6,1.2,1.9);
   glScaled(1,0.02,1);
   glutSolidCube(.5);
   glColor3f(0,0,0);
   glutWireCube(0);
   glPopMatrix();



glPushMatrix(); //sub building 2
   glColor3f(0.91, 0.76,0.65);
   glTranslated(2.4,0.4,2.0);
   glScaled(.5,0.8,2);
   glutSolidCube(1);
   glColor3f(0.91, 0.76,0.65);
   glutWireCube(1);
   glPopMatrix();

 glPushMatrix(); // sub building 2 door
   glColor3f(0,0,0);
   glTranslated(2.4,0.15,1.9);
   glScaled(0.2,0.3,1);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();



   glPushMatrix(); //sub building 2 room roof
   glColor3f(0,0,0);
   glTranslated(2.4,0.4,1.9);
   glScaled(1,0.02,1);
   glutSolidCube(.5);
   glColor3f(0,0,0);
   glutWireCube(0);
   glPopMatrix();

    glPushMatrix(); // sub building 2 Top door
   glColor3f(0,0,0);
   glTranslated(2.4,0.6,1.9);
   glScaled(0.2,0.3,1);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();

    glPushMatrix(); // sub building 2 Top roof
   glColor3f(0,0,0);
   glTranslated(2.4,.8,1.9);
   glScaled(1,0.02,1);
   glutSolidCube(.7);
   glColor3f(0,0,0);
   glutWireCube(0);
   glPopMatrix();




glPushMatrix(); //side brench
   glColor3f(0.6, 0.4,0.2);
   glTranslated(1,-0.86,1.0);
   glScaled(.5,0.25,2);
   glutSolidCube(1);
   glColor3f(0.91, 0.76,0.65);
   glutWireCube(1);
   glPopMatrix();


glPushMatrix(); //side brench Setting
   glColor3f(0,0,0);
   glTranslated(1,-0.88,.8);
   glScaled(.3,0.22,6);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();


glPushMatrix(); //side brench
   glColor3f(0.6, 0.4,0.2);
   glTranslated(3,-0.86,1.0);
   glScaled(.5,0.25,2);
   glutSolidCube(1);
   glColor3f(0.91, 0.76,0.65);
   glutWireCube(1);
   glPopMatrix();


glPushMatrix(); //side brench Setting
   glColor3f(0,0,0);
   glTranslated(3,-0.88,.8);
   glScaled(.3,0.22,6);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();



   glPushMatrix(); //side brench
   glColor3f(0.6, 0.4,0.2);
   glTranslated(-3,-0.86,1.0);
   glScaled(.5,0.25,2);
   glutSolidCube(1);
   glColor3f(0.91, 0.76,0.65);
   glutWireCube(1);
   glPopMatrix();


glPushMatrix(); //side brench Setting
   glColor3f(0,0,0);
   glTranslated(-3,-0.88,.8);
   glScaled(.3,0.22,6);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();




   glPushMatrix(); //side brench
   glColor3f(0.6, 0.4,0.2);
   glTranslated(-1.4,-0.86,1.0);
   glScaled(.5,0.25,2);
   glutSolidCube(1);
   glColor3f(0.91, 0.76,0.65);
   glutWireCube(1);
   glPopMatrix();


glPushMatrix(); //side brench Setting
   glColor3f(0,0,0);
   glTranslated(-1.4,-0.88,.8);
   glScaled(.3,0.22,6);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();


   glPushMatrix(); // midle bar
   glColor3f(1, 1,1);
   glTranslated(-1.4,-1.5,1.0);
   glScaled(.5,0.07,2);
   glutSolidCube(1);
   glPopMatrix();

   glPushMatrix(); //midle bar
   glColor3f(1, 1,1);
   glTranslated(-2.8,-1.5,1.0);
   glScaled(.5,0.07,2);
   glutSolidCube(1);
   glPopMatrix();



     glPushMatrix(); //midle bar
   glColor3f(1, 1,1);
   glTranslated(2.6,-1.5,1.0);
   glScaled(.5,0.07,2);
   glutSolidCube(1);
   glPopMatrix();


  glPushMatrix(); //midle bar
   glColor3f(1, 1,1);
   glTranslated(1.3,-1.5,1.0);
   glScaled(.5,0.07,2);
   glutSolidCube(1);
   glPopMatrix();

     glPushMatrix(); //midle bar
   glColor3f(1, 1,1);
   glTranslated(-0.1,-1.5,1.0);
   glScaled(.5,0.07,2);
   glutSolidCube(1);
   glPopMatrix();



}




void trainStruc()
{
   glPushMatrix(); //Right Wheel Far
   glColor3f(1,1,1);
   glTranslated(0.75,-0.5, -0.5);
   glRotated(angle,0,0,1);
   glutWireTorus (0.1,0.2,10,10);
   glPopMatrix();

   glPushMatrix(); //Left Wheel Far
   glColor3f(1,1,1);
   glTranslated(-0.75,-0.5, -0.5);
   glRotated(angle,0,0,1);
   glutWireTorus (0.1,0.2,10,10);
   glPopMatrix();

   glPushMatrix(); //Train BOX
   glColor3f(.3, 0.5,0.7 );
   glScaled(2,1,1);
   glutSolidCube(1);
   glColor3f(0,0,0);
   glutWireCube(1);
   glPopMatrix();


   glPushMatrix(); //Train Connection Boxes
   glColor3f(0,0,0);
   glTranslated(1,-0.35,0);
   glScaled(1,0.09,0.09);
   glutSolidCube(1);
   glPopMatrix();

   glPushMatrix(); //Right Wheel Far
   glColor3f(1,1,1);
   glTranslated(0.75,-0.5, 0.5);
   glRotated(angle,0,0,1);
   glutWireTorus (0.1,0.2,10,10);
   glPopMatrix();

   glPushMatrix(); //Left Wheel Far
   glColor3f(1,1,1);
   glTranslated(-0.75,-0.5, 0.5);
   glRotated(angle,0,0,1);
   glutWireTorus (0.1,0.2,10,10);
   glPopMatrix();

   angle-=0.2;
}

void tree()
{
   glPushMatrix();
   	glColor3b(102,100,70);
   	glScaled(0.2,6,0.9);
  	glutSolidCube(1);
   glPopMatrix();

   glPushMatrix();
     	glColor3b(48,124,66);
     	glTranslated(0,2,0);
    	glutSolidSphere(1,8,10);
    	glColor3f(0,1,0);
    	glutWireSphere(1,8,8);
    	glPopMatrix();
}
void background()
{


   glColor3f(0.24,0.56,0.37);
   glRecti(-3,-2,3,0); //green grass

   	glColor3f(0.1, 0.2,0.2);
  	glRecti(-4,-1,4.5,-2); //Highway

  	glColor3f(0.13,0.68,0.85);
  	glRecti(-3,0,3,2); //sky






 //small trees
   glPushMatrix();
   glTranslated(1.7,0.6,0);
   glScaled(0.3,0.3,0.1);
   tree();
   glPopMatrix();
  	glPushMatrix();
   glTranslated(1.5,0.8,0);
   glScaled(0.3,0.3,0.1);
   tree();
   glPopMatrix();


   //small trees
   glPushMatrix();
   glTranslated(-1.9,0.6,0);
   glScaled(0.3,0.3,0.1);
   tree();
   glPopMatrix();
  	glPushMatrix();
   glTranslated(1.5,0.8,0);
   glScaled(0.3,0.3,0.1);
   tree();
   glPopMatrix();

 //small trees 2 Myself
    glPushMatrix();
   glTranslated(1.9,0.6,0);
   glScaled(0.3,0.3,0.1);
   tree();
   glPopMatrix();
  	glPushMatrix();
   glTranslated(1.5,0.5,2);
   glScaled(0.3,0.3,1.9);
   tree();
   glPopMatrix();



   //big trees
   glPushMatrix();
     	glTranslated(-1.6,0.4,0);
     	glScaled(0.23,0.23,0.1);
     	tree();
    	glPopMatrix();
 	glPushMatrix();
     	glTranslated(-1.4,0.6,0);
     	glScaled(0.23,0.23,0.1);
     	tree();
    	glPopMatrix();


 home();
}
void renderScene (void)
{
   glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glMatrixMode (GL_PROJECTION);
   glLoadIdentity();
   glOrtho (-3,3,-2,2,-4,4);
   background ();
   glRotatef(10,1.0,1.0,0.0); //
   glPushMatrix ();

   glColor3f(0,0,0); //Rail
   glTranslated (0,-0.4,0);
   glScaled (9,0.1,0.1);
   glutWireCube(1);
   glPopMatrix();

   glTranslatef(x,0,0); // to move train
   glScaled(0.5,0.5,0.5);

   glPushMatrix();
   glTranslated (-2.4,0,0);
   trainStruc();
   glPopMatrix();
   glPushMatrix();
   glTranslated (0,0,0);
   trainStruc();
   glPopMatrix();
   glPushMatrix();
   glTranslated (2.4,0,0);
   trainStruc();
   glPopMatrix();
   if (x<6)
  	x+=0.002; //control train speed from here
   else
  	x=-6;


   glutSwapBuffers();
   }

int main(int argc,char** argv) {
    glutInit(&argc,argv); // Initialize GLUT
glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
glutInitWindowPosition (10,10); // Position the window's initial top-lef
glutInitWindowSize (1200,600); // Set the window's initial width & height
glutCreateWindow("Home");
glutDisplayFunc(renderScene);
glutIdleFunc (renderScene); // callbacks for main window
glClearColor(1,1,1,1);
glutMainLoop(); // Enter the event-processing loop

return 0;
}
